<?php

namespace MercadoPago\PP\Sdk\Common;

/**
 * Class Constants
 *
 * @package MercadoPago\PP\Sdk\Common
 */
class Constants
{
    const BASEURL_MP = 'https://api.mercadopago.com';
    const BASEURL_ML = 'https://api.mercadolibre.com';
}
