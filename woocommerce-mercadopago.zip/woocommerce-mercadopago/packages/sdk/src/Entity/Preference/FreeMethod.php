<?php

namespace MercadoPago\PP\Sdk\Entity\Preference;

use MercadoPago\PP\Sdk\Common\AbstractEntity;

/**
 * Class FreeMethod
 *
 * @package MercadoPago\PP\Sdk\Entity\Preference
 */
class FreeMethod extends AbstractEntity
{
    /**
     * @var int
     */
    protected $id;
}
