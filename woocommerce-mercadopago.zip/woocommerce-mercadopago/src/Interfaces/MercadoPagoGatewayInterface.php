<?php

namespace MercadoPago\Woocommerce\Interfaces;

if (!defined('ABSPATH')) {
    exit;
}

interface MercadoPagoGatewayInterface
{
    /**
     * @return void
     */
    public function init_form_fields(): void;

    /**
     * @param string $gatewaySection
     * @return void
     */
    public function payment_scripts(string $gatewaySection): void;

    /**
     * @return void
     */
    public function payment_fields(): void;

    /**
     * @return bool
     */
    public function validate_fields(): bool;

    /**
     * @param int $order_id
     *
     * @return array
     */
    public function process_payment(int $order_id): array;

    /**
     * @return void
     */
    public function webhook(): void;
}
